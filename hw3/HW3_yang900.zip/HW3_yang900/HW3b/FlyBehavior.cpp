#include <iostream>
#include <string>
#include "FlyBehavior.h"

FlyBehavior::FlyBehavior( ) { }

FlyBehavior::~FlyBehavior( ){ }

void FlyBehavior::fly( ) {
    std::cout<<"I'm flying"<<std::endl;
}

