#include "Base.h"

Base::Base( ) { }
Base::~Base( ) { }

// include necessary function definitions here
void Base::f1(){
    std::cout<<"Base f1\n";

}
void Base::f2(){
    std::cout<<"Base f2\n";

}