#include "Derived.h"

Derived::Derived( ) { }
Derived::~Derived( ) { }

// add necessary functions here
void Derived::f2(){
    std::cout<<"Derived f2\n";
}