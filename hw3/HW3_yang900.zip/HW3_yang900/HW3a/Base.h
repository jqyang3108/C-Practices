#ifndef BASE_H_
#define BASE_H_
#include <string>
#include <iostream>

class Base {
public:
   Base( );
   virtual ~Base( );
   // add necessary functions here
   void f1();
   virtual void f2();
};
#endif /*BASE_H*/
